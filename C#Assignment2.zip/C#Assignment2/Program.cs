﻿namespace C_Assignment2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Aayush Ogia Assignment 2
            //Name of the Project: Tax according to the age group
            //Purpose: To calculate the final amount
            //Revision History;

            Console.WriteLine("\nPlease enter applicant's age: ");
            int applicant = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("\nPlease enter the currency you wish to pay in(USD/CAD/BITCOIN): ");
            string currency = Convert.ToString(Console.ReadLine());

            Console.WriteLine("\nAre you refered by someone or not? (true/false)");
            bool condition = Convert.ToBoolean(Console.ReadLine());

            double price = 0;

            if (applicant <= 13)
            {
                Console.WriteLine("\nSorry, You can't register.");
                return;
            }

            else if (applicant >= 14 && applicant <= 19)
            {
                Console.WriteLine("\nYou must pay $10 and no tax.");
                price = 10;
                Console.WriteLine("Price for this group is: " + price + "$");
            }

            else if (applicant >= 20 && applicant <= 29)
            {
                Console.WriteLine("\nYou must pay $35.50 + 13%HST.");
                price = 35.50 + (13 * 35.5) / 100;
                Console.WriteLine("Price for  this age group is: " + price + "$");
            }

            else if (applicant >= 30 && applicant <= 64)
            {
                Console.WriteLine("\nYou must pay $70.50 + 13%HST.");
                price = 70.50 + (13 * 70.50) / 100;
                Console.WriteLine("Price for this age group is: " + price + "$");
            }

            else if (applicant >= 65)
            {
                Console.WriteLine("Hurrey, You are free.");
            }

            else
            {
                Console.WriteLine("Wrong Choice");
            }

            if (condition == true)
            {
                Console.WriteLine("After refferal discount, You get $25 off from the final fee");
                price = (price - 25);
                if (price <= 0)
                {
                    price = 0;
                }
                Console.WriteLine("Final fee is: " + price + "$");
            }

            else
            {
                Console.WriteLine("OOps, You are not refered.!!!");
            }
            double price1 = price;

            /* logic 2.Step 2: Ask for the month the applicant wishes to start their subscription. You must use a switch statement to get
            full marks.
            Logic:
             For month January and February, subtract $10 for each month from the final fee
             For March, add 10 % discount
             If the month is April & May, add $20 + 13 % HST
             For all other months(i.e.June to December), no adjustment */

            Console.WriteLine("\n\nPlease enter the month, from when you would like to start your subcription:-");
            string month = Console.ReadLine();


            switch (month)
            {

                case "january":
                case "february":
                    Console.WriteLine("You have to pay $10 less in this month from the final fee.");
                    price = (price - 10);
                    if (price >= 0)
                    {
                        Console.WriteLine(price + "$");
                    }
                    else
                    {
                        Console.WriteLine("0$");
                    }
                    break;


                case "march":
                    Console.WriteLine("Hurrey, You will get 10% discount on final price.");
                    price = price - (price * 0.1);
                    Console.WriteLine(price + "$");

                    break;


                case "april":
                case "may":
                    Console.WriteLine("OOPS, You have to pay $20 + 13%HST on final price.");
                    price = price + 20 + (price * 0.13);
                    Console.WriteLine(price + "$");
                    break;

                case "june":
                case "july":
                case "august":
                case "september":
                case "october":
                case "november":
                case "december":
                    Console.WriteLine("There is no adjustment for these following months.");
                    break;
                default:
                    Console.WriteLine("Please enter correct month: ");
                    break;
            }
            double price2 = price;

            // Add an additional 9% tax to the final amount (step 1 + step 2)

            double finalprice = price1 + price2;
            double finalprice2 = finalprice + (finalprice * 0.09);
            if (finalprice <= 0)
            {
                finalprice = 0;
                Console.WriteLine("\n\nThe final fee for the following month is: " + finalprice + "$");
            }
            else
            {
                Console.WriteLine("\n\nThe final fees for the following month is: " + finalprice2 + "$");
            }
        }
    }
}